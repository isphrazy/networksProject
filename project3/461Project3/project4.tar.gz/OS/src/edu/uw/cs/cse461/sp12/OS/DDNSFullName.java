package edu.uw.cs.cse461.sp12.OS;

public class DDNSFullName {
	String hostname;
	
	public DDNSFullName(String hostname) {
		this.hostname = hostname;
	}
}
